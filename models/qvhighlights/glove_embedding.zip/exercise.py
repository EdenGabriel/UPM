from torchtext import vocab
import torch
import torch.nn as nn
import pandas as pd
import polars as pl
import pickle

class GLOVE(object):
    def __init__(self, ):
        self.vocab = vocab.pretrained_aliases['glove.6B.300d']()
        self.vocab.itos.extend(['<unk>'])
        self.vocab.stoi['<unk>'] = self.vocab.vectors.shape[0]
        self.vocab.vectors = torch.cat(
            (self.vocab.vectors, torch.zeros(1, self.vocab.dim)), dim=0)
        self.embedding = nn.Embedding.from_pretrained(self.vocab.vectors)

    def get_query(self,query):
        word_inds = torch.LongTensor(
            [self.vocab.stoi.get(w.lower(), 400000) for w in query.split()])
        return self.embedding(word_inds)
    
df = pl.read_csv("./sampled_data.csv")
# df = pd.read_csv('./sampled_data.csv')

# Group by consumer and aggregate the 'store' and 'duration_in_sec' columns into lists
aggregated_df = df.groupby('pid_id').agg(pl.col('store_duration').alias('store_list'))
# Filter out rows where store_sequence has only 2 elements and they are the same
# aggregated_df = aggregated_df.filter(~((aggregated_df["store_list"].len() == 3) & (aggregated_df["store_list"].apply(lambda x: x[0] == x[1]))))

# Convert store sequences into a list of lists for Word2Vec training
sentences = aggregated_df["store_list"].to_list()

glove = GLOVE()

embedding_dict = {}
for i in range(len(sentences)):
    for j in range(len(sentences[i])):
        # term = sentences[i][j]
        term = sentences[i][j].replace('_', ' ')
        if term not in embedding_dict:  # check if the embedding vector exists in the dict
            embedding_dict[term] = glove.get_query(term).detach().numpy()
            # if u want to store the embedding vectors as tensors in the dictionary, you can directly store them
            # if u want to store the embedding vectors as NumPy arrays, you can use the .detach().numpy() method

filename = 'embedding_dict.pkl'
with open(filename, 'wb') as f:
    pickle.dump(embedding_dict, f)
print(f"Embedding dictionary saved to {filename}")

 # Split each (store, duration_bucket) pair to get the store name
store_names = [pair.rsplit(' ', 1)[0] for pair in embedding_dict.keys()]

aggregated_embeddings = {}
# Aggregate embeddings for each store
for store in set(store_names):
    store_pairs = [pair for pair in embedding_dict.keys()]

    # Average the embeddings of all pairs for this store
    aggregated_embeddings[store] = np.mean([embedding_dict[pair][:-1] for pair in store_pairs], axis=0)

    # Extract all store embeddings into a list and maintain their order
    stores = list(aggregated_embeddings.keys())
    embeddings_list = [aggregated_embeddings[store] for store in stores]

    embeddings_dict = dict(zip(stores, embeddings_list))